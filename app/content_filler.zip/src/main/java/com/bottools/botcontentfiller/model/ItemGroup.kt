package com.bottools.botcontentfiller.model

enum class ItemGroup {
    Wearable,
    Ammo,
    Food,
    MeleeWeapon,
    RangeWeapon,
    Resource,
    Default
}