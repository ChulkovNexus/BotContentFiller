package com.bottools.botcontentfiller.model

enum class WearType {
    Pants,
    Chest,
    Shirt,
    Helmet,
    Body,
    Default
}
