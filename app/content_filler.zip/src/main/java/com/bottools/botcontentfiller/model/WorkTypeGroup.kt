package com.bottools.botcontentfiller.model

enum class WorkTypeGroup {
    Default,
    Outside,
    Inside
}